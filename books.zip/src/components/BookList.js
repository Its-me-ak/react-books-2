import BookShow from "./BookShow"

function BookList({ books, onDelete }) {

  const renderBooks = books.map((book) => {
    return <BookShow deleteBook={onDelete} key={book.id} book={book.title} />
  })

  return (
    <>
      <div className="book-list">
        {renderBooks}
      </div>
    </>
  )
}

export default BookList
